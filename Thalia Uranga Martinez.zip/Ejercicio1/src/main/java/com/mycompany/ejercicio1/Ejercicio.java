package com.mycompany.ejercicio1;


import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Thalia Uranga Martinez
 */
public class Ejercicio {
    public static void main (String args[]) throws Exception{
        List<Cuenta> cuentas = new ArrayList();
        int mes = 0;  
        int totalCargo = 0;
        int totalAbono = 0;
        int total;
        String urlArchivo = "";
        //Recorremos los datos que contiene arguments y en este caso, introducimos el mes
        for (String arg : args) {            
            mes = Integer.parseInt(arg);
        }        
        if(mes > 12){
            System.out.println("No puede exceder de 12");
            System.exit(0);
        }
        if(mes <= 0){
            System.out.println("No puede ser menor de 0");
            System.exit(0);
        }               
        LecturaArchivo lecturaArchivo = new LecturaArchivo();       
        //Ejecucion de archivo de forma local
        //urlArchivo = lecturaArchivo.getFileFromResources("Ejercicio.csv");
        //Ejecucion de archivo con JAR
        urlArchivo = "./Ejercicio.csv";
        System.out.println("Leyendo archivo desde...");
        System.out.println(urlArchivo);

        try{            
            cuentas = lecturaArchivo.leerArchivo(urlArchivo, mes);              
        } catch (IOException e) {
            System.out.println("Este es un mensaje " + e.getMessage());
        }        
        //Total de cargos y abonos y total general 
        for(int i=0; i<cuentas.size(); i++){
            if(cuentas.get(i).getOperacion() == 1){
                totalAbono = totalAbono + cuentas.get(i).getMonto();                
            }else if(cuentas.get(i).getOperacion() == 0){
                totalCargo = totalCargo + cuentas.get(i).getMonto();
            }
        }
        //Impresion en pantalla 
        System.out.println("Mes: " + mes);
        System.out.println("Total cargos: " + totalCargo);
        System.out.println("Total abonos: " + totalAbono);
        total = totalAbono - totalCargo;
        System.out.println("Total: " + total);
                
        HashMap<Integer, Cuenta> cuentasHashMap = new HashMap<>();
        
        for(int i=0; i<cuentas.size(); i++){          
            if(cuentasHashMap.containsKey(cuentas.get(i).getCuenta())){                
                Cuenta updateValue = cuentasHashMap.get(cuentas.get(i).getCuenta());                
                if(cuentas.get(i).getOperacion() == 0){
                    updateValue.setMonto(updateValue.getMonto() - cuentas.get(i).getMonto());
                } else
                    if (cuentas.get(i).getOperacion() == 1){
                        updateValue.setMonto(updateValue.getMonto() + cuentas.get(i).getMonto());
                    }                
                cuentasHashMap.put(updateValue.getCuenta(), updateValue);                
            } else {
                cuentasHashMap.put(cuentas.get(i).getCuenta(), cuentas.get(i));
            }            
        }
        
        System.out.println("\nArchivo Salida \n");
        try (FileWriter archivoSalida = new FileWriter("./archivoSalida.csv")) {
            TreeMap<Integer, Cuenta> ordenado = new TreeMap(cuentasHashMap);
            for(Cuenta a : ordenado.values()){
                if(a.getMonto()<0){
                    archivoSalida.append(a.getCuenta() + ",(" + (a.getMonto()*(-1)) + ")");
                    archivoSalida.append("\n");
                    System.out.println(a.getCuenta() + ",(" + (a.getMonto()*(-1)) + ")");
                } else
                    if(a.getMonto()>0){
                        archivoSalida.append(a.getCuenta()+","+a.getMonto());
                        archivoSalida.append("\n");
                        System.out.println(a.getCuenta()+","+a.getMonto());
                    }
            }
            archivoSalida.flush();
        } 
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }    
}
