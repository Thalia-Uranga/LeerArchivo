package com.mycompany.ejercicio1;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Thalia Uranga Martinez
 */
public class LecturaArchivo {
    private final String SEPARATOR = ",";
    private final String formatZone = "dd/MM/yyyy";
    private final int CUENTA = 0;
    private final int MONTO = 1;
    private final int OPERACION = 2;
    private final int FECHA = 3;
    
    public LecturaArchivo(){        
    }
    
    public List<Cuenta> leerArchivo(String rutaArchivo, int mes) throws IOException{
        BufferedReader br = null;        
        List<Cuenta> cuentas = new ArrayList();
        
        try{    
           br = new BufferedReader(new FileReader(rutaArchivo));
           String line = br.readLine();
           while(null != line){
               if(line.startsWith("Cuenta")){
                   System.out.println("Leyendo cabeceras del archivo");
               } else {
                   String[] fields = line.split(SEPARATOR);
                   int cuenta = Integer.parseInt(fields[CUENTA].trim());
                   int monto = Integer.parseInt(fields[MONTO].trim());
                   int operacion = Integer.parseInt(fields[OPERACION].trim());
                   SimpleDateFormat sdf = new SimpleDateFormat(formatZone);
                   Date fecha = sdf.parse(fields[FECHA].trim());
                   
                   Calendar cal = Calendar.getInstance();
                   cal.setTime(fecha);
                   int month = cal.get(Calendar.MONTH);
                   month = month + 1;                   
                   if(month == mes){
                       cuentas.add(new Cuenta(cuenta, monto, operacion, fecha));
                   }
               } 
               line = br.readLine();
               
           }
       } catch (IOException | NumberFormatException | ParseException e){
           System.out.println(e.getMessage());
            System.out.println(e.getCause());
       }
       finally {
            if(null != br){
                br.close();
            }
        }
        return cuentas;
    } 
    
    public String getFileFromResources(String fileName) {
        ClassLoader classLoader = getClass().getClassLoader();
        URL resource = classLoader.getResource(fileName);
        if (resource == null) {
            throw new IllegalArgumentException("file is not found!");
        } else {
            return new File(resource.getFile()).getAbsolutePath();
        }

    }
}
