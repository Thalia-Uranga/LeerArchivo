package com.mycompany.ejercicio1;


import java.util.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author luisolartegervacio
 */
public class Cuenta {
    private int cuenta;
    private int monto;
    private int operacion;
    private Date fecha;

    public Cuenta(int cuenta, int monto, int operacion, Date fecha) {
        this.cuenta = cuenta;      
        this.monto = monto;
        this.operacion = operacion;
        this.fecha = fecha;
    }

    public Cuenta() {
    }

    public int getCuenta() {
        return cuenta;
    }

    public void setCuenta(int cuenta) {
        this.cuenta = cuenta;
    }

    public int getMonto() {
        return monto;
    }

    public void setMonto(int monto) {
        this.monto = monto;
    }

    public int getOperacion() {
        return operacion;
    }

    public void setOperacion(int operacion) {
        this.operacion = operacion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Cuenta{" + "cuenta=" + cuenta + 
                ", monto=" + monto + 
                ", operacion=" + operacion +
                ", fecha=" + fecha + '}';
    }   
    
}
